var pos = ["s", "s", "s", "s", "s", "s", "s", "s",  "s"];
var jogaprimeiro = 'X';
var jogadorAtual = 'X';
var ponto_X = 0;
var ponto_O = 0;
var verificaS


var leNomes = function(){
    var nome1 = prompt("Digite o nome do jogador 1");
    document.getElementById("placarP1").innerHTML = nome1 + '<div id="placarP1">:</div>'

    var nome2 = prompt("Digite o nome do jogador 2");
    document.getElementById("placarP2").innerHTML = nome2 + '<div id="placarP2">:</div>'


}

var verificaGanhador = function(){
     var ganhador = 's';
    if(
        ((pos[0] == pos[1]) && (pos[1] == pos[2]) ||
        (pos[0]== pos[3]) && (pos[3] == pos[6]) ||
        (pos[0] == pos[4]) && (pos[4] == pos[8]) 
        )
    ){ganhador = pos[0];}
    if(
        ((pos[1] == pos[4]) && (pos[4] == pos[7])
    )
    ){ganhador = pos[1];}
    if(
        ((pos[2] == pos[4]) && (pos[4] == pos[6]) ||
        (pos[2]== pos[5]) && (pos[5] == pos[8]) 
    ) 
    ){ganhador = pos[2];}
    if(
        ((pos[3] == pos[4]) && (pos[4] == pos[5])
    )
    ){ganhador = pos[3];}
    if(
        ((pos[6] == pos[7]) && (pos[4] == pos[8])
    )
    ){ganhador = pos[6];}

    return ganhador;
        
} 

var simbolo = function(posicao) {
    if (pos[parseInt(posicao)] == 's') {
        if (jogadorAtual == 'X') {
            document.getElementById(posicao).innerHTML = '<div class = "simbolo">X</div>';
            pos[parseInt(posicao)] = "X";
            jogadorAtual = "O";
        } else {
            document.getElementById(posicao).innerHTML = '<div class = "simbolo">O</div>';
            pos[parseInt(posicao)] = "O";
            jogadorAtual = "X";
        }
    }

    if (verificaGanhador() != 's') {
        if (verificaGanhador() == 'X') {
            ponto_X++;
        } else {
            ponto_O++;
        }
        alert(verificaGanhador() + "Parabéns meu jovem!");

        pos = ["s", "s", "s", "s", "s", "s", "s", "s", "s"];
        if (jogaprimeiro == 'X') {
            jogaprimeiro == 'O'
        } else {
            jogaprimeiro == 'X'
        }
        jogadorAtual == jogaprimeiro;
        for (var i = 0; i < 9; i++) {
            document.getElementById(i.toString()).innerHTML = '<div class = "simbolo"></div>';
        }
        for (var i = 0; i < 9; i++) {
            document.getElementById(i.toString()).innerHTML = "<di></div>";
        }
        document.getElementById("placarP1").innerHTML = placarP1 + ":" + ponto_X;
        document.getElementById("placarP2").innerHTML = placarP2 + ":" + ponto_O;
    
    }else {
        verificaS='s'
        for(var i=0; i < 9; i++){
            if(pos[i]=='s'){
                verificaS = 's'
            }
        }
        if(verificaS != 's'){
            alert(verificaS + "Deu VELHA jovem!")
        
        }
    } 
}
















